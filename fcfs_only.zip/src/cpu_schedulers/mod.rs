pub mod preemptive;
pub mod nonpreemptive;

/// `Process` struct.
pub struct Process {
    pub name: String,
    pub arrival_time: u32,
    pub burst_time: u32,
}

impl Process {
    /// Constructor for `Process` struct.
    fn new(name: &str, arrival_time: u32, burst_time: u32) -> Process {
        Process {
            name: name.to_string(),
            arrival_time,
            burst_time,
        }
    }
}

/// `Event` struct.
pub struct Event {
    pub name: String,
    pub start_time: u32,
    pub finish_time: u32,
}