use super::{Process, Event};

pub struct NonpreemptiveScheduler {
    pub processes: Vec<Process>,
    pub processes_finish_time: Vec<u32>,
    pub processes_waiting_time: Vec<u32>,
    pub processes_turn_around_time: Vec<u32>,
}

// Common methods
impl NonpreemptiveScheduler {
    // Constructor
    fn new(process: Vec<Process>) -> NonpreemptiveScheduler {
        // Panic if the process vector is empty
        if process.is_empty() {
            panic!("The process vector is empty!");
        }

        NonpreemptiveScheduler {
            processes: process,
            processes_finish_time: Vec::new(),
            processes_waiting_time: Vec::new(),
            processes_turn_around_time: Vec::new(),
        }
    }

    // Methods
    fn sort_by_arrival_time(&mut self) {
        self.processes.sort_by(|a, b| a.arrival_time.cmp(&b.arrival_time));
    }

    fn calculate_finish_time(&mut self) {
        let mut finish_time = 0;
        for i in 0..self.processes.len() {
            finish_time += self.processes[i].burst_time;
            self.processes_finish_time.push(finish_time);
        }
    }

    fn  calculate_waiting_time(&mut self) {
        let mut waiting_time = 0;
        for i in 0..self.processes.len() {
            self.processes_waiting_time.push(waiting_time);
            waiting_time += self.processes[i].burst_time;
        }
    }

    fn calculate_turn_around_time(&mut self) {
        for i in 0..self.processes.len() {
            self.processes_turn_around_time
                .push(self.processes[i].burst_time + self.processes_waiting_time[i]);
        }
    }

    fn calculate_average_waiting_time(&mut self) -> f32 {
        let mut total_waiting_time = 0;
        for i in 0..self.processes.len() {
            total_waiting_time += self.processes_waiting_time[i];
        }
        total_waiting_time as f32 / self.processes.len() as f32
    }

    fn calculate_average_turn_around_time(&mut self) -> f32 {
        let mut total_turn_around_time = 0;
        for i in 0..self.processes.len() {
            total_turn_around_time += self.processes_turn_around_time[i];
        }
        total_turn_around_time as f32 / self.processes.len() as f32
    }
}

// Visualization
impl NonpreemptiveScheduler {
    pub fn print(&mut self) {
        println!("Name\t\tArrival Time\tBurst Time\tWaiting Time\tTurn Around Time\tFinish Time");
        for i in 0..self.processes.len() {
            println!(
                "{}\t\t{}\t\t{}\t\t{}\t\t{}\t\t\t{}",
                self.processes[i].name,
                self.processes[i].arrival_time,
                self.processes[i].burst_time,
                self.processes_waiting_time[i],
                self.processes_turn_around_time[i],
                self.processes_finish_time[i]
            );
        }
        println!(
            "Average:\t\t\t\t\t*{}\t\t*{}", 
            self.calculate_average_waiting_time(), 
            self.calculate_average_turn_around_time()
        );

        self.gantt_chart();
    }

    // Idea from: https://github.com/marvinjason/CPUScheduler
    pub fn gantt_chart(&self) {
        let mut gantt_chart = "\n\nGantt Chart:\n".to_string();
        let mut time = 0;
        let number_of_processes = self.processes.len();
        if number_of_processes == 1 {
            gantt_chart.push_str(&format!("{}\n", self.processes_waiting_time[0]));
            gantt_chart.push_str(&format!("|    {}\n", self.processes[0].name));
            gantt_chart.push_str(&format!("{}\n", self.processes_finish_time[0]));
        } else {
            gantt_chart.push_str(&format!("{}\n", self.processes_waiting_time[0]));
            gantt_chart.push_str(&format!("|    {}\n", self.processes[0].name));

            for i in 1..self.processes.len() {
                time += self.processes[i - 1].burst_time;
                gantt_chart.push_str(&format!("{}\n", time));
                gantt_chart.push_str(&format!("|    {}\n", self.processes[i].name));
            }
            gantt_chart.push_str(&format!("{}\n", self.processes_finish_time[number_of_processes - 1]));
        }
        println!("{}", gantt_chart);
    }
}

// Algorithms
impl NonpreemptiveScheduler {
    // First Come First Serve (FCFS).
    pub fn fcfs(&mut self) {
        self.sort_by_arrival_time();
        self.calculate_waiting_time();
        self.calculate_finish_time();
        self.calculate_turn_around_time();
        self.print();
    }

    // Shortest Job First (SJF).
    pub fn sjf(&mut self) {
        
    }
}

// Tests
#[cfg(test)]

mod test {
    use super::*;

    #[test]
    fn test_sjf() {
        let mut scheduler = NonpreemptiveScheduler::new(vec![
            Process::new("P1", 2, 6),
            Process::new("P2", 5, 2),
            Process::new("P3", 1, 8),
            Process::new("P4", 0, 3),
            Process::new("P5", 4, 4),
        ]);
        scheduler.fcfs();
    }
}